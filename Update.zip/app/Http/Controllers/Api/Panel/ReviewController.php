<?php

namespace App\Http\Controllers\Api\Panel;

use App\Http\Controllers\Api\Traits\ReviewTrait;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    //
    use ReviewTrait;
}
