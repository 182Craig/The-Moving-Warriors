<?php

namespace App\Models\Api;

use App\Models\WebinarAssignmentAttachment as Model;

class WebinarAssignmentAttachment extends Model
{
    //
}
