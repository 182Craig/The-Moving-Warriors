<?php
namespace App\Channels;

class AgoraDynamicKey
{

}
